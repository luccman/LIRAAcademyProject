﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormRegister
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.StudentsBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.LiraDatabaseLatestBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.LiraDatabaseLatest = New LoginForUsers.LiraDatabaseLatest()
        Me.StudentsBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.StudentsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.LIRADATABASEDataSet = New LoginForUsers.LIRADATABASEDataSet()
        Me.LIRADATABASEDataSet3 = New LoginForUsers.LIRADATABASEDataSet3()
        Me.LIRADATABASEDataSet3BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.SubjectsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.SubjectsTableAdapter = New LoginForUsers.LIRADATABASEDataSet3TableAdapters.SubjectsTableAdapter()
        Me.StudentsTableAdapter = New LoginForUsers.LIRADATABASEDataSetTableAdapters.StudentsTableAdapter()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.StudentsTableAdapter1 = New LoginForUsers.LiraDatabaseLatestTableAdapters.StudentsTableAdapter()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.SubjectsBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.StudentsBindingSource3 = New System.Windows.Forms.BindingSource(Me.components)
        Me.SubjectsTableAdapter1 = New LoginForUsers.LiraDatabaseLatestTableAdapters.SubjectsTableAdapter()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ComboBox5 = New System.Windows.Forms.ComboBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.SubjectsBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.ComboBox7 = New System.Windows.Forms.ComboBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.SubjectsBindingSource3 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.ComboBox9 = New System.Windows.Forms.ComboBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.SubjectsBindingSource4 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.ComboBox11 = New System.Windows.Forms.ComboBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.SubjectsBindingSource5 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.ComboBox13 = New System.Windows.Forms.ComboBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.SubjectsBindingSource6 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.ComboBox15 = New System.Windows.Forms.ComboBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.SubjectsBindingSource7 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.ComboBox17 = New System.Windows.Forms.ComboBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.StudentsBindingSource4 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.RegisteredStudentsListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentsRegisteredSubjectsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.StudentsBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LiraDatabaseLatestBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LiraDatabaseLatest, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StudentsBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StudentsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LIRADATABASEDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LIRADATABASEDataSet3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LIRADATABASEDataSet3BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SubjectsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.SubjectsBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StudentsBindingSource3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.SubjectsBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        CType(Me.SubjectsBindingSource3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox6.SuspendLayout()
        CType(Me.SubjectsBindingSource4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox7.SuspendLayout()
        CType(Me.SubjectsBindingSource5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox8.SuspendLayout()
        CType(Me.SubjectsBindingSource6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox9.SuspendLayout()
        CType(Me.SubjectsBindingSource7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StudentsBindingSource4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'StudentsBindingSource2
        '
        Me.StudentsBindingSource2.DataMember = "Students"
        Me.StudentsBindingSource2.DataSource = Me.LiraDatabaseLatestBindingSource
        '
        'LiraDatabaseLatestBindingSource
        '
        Me.LiraDatabaseLatestBindingSource.DataSource = Me.LiraDatabaseLatest
        Me.LiraDatabaseLatestBindingSource.Position = 0
        '
        'LiraDatabaseLatest
        '
        Me.LiraDatabaseLatest.DataSetName = "LiraDatabaseLatest"
        Me.LiraDatabaseLatest.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'StudentsBindingSource1
        '
        Me.StudentsBindingSource1.DataMember = "Students"
        Me.StudentsBindingSource1.DataSource = Me.LiraDatabaseLatest
        '
        'StudentsBindingSource
        '
        Me.StudentsBindingSource.DataMember = "Students"
        Me.StudentsBindingSource.DataSource = Me.LIRADATABASEDataSet
        '
        'LIRADATABASEDataSet
        '
        Me.LIRADATABASEDataSet.DataSetName = "LIRADATABASEDataSet"
        Me.LIRADATABASEDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'LIRADATABASEDataSet3
        '
        Me.LIRADATABASEDataSet3.DataSetName = "LIRADATABASEDataSet3"
        Me.LIRADATABASEDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'LIRADATABASEDataSet3BindingSource
        '
        Me.LIRADATABASEDataSet3BindingSource.DataSource = Me.LIRADATABASEDataSet3
        Me.LIRADATABASEDataSet3BindingSource.Position = 0
        '
        'SubjectsBindingSource
        '
        Me.SubjectsBindingSource.DataMember = "Subjects"
        Me.SubjectsBindingSource.DataSource = Me.LIRADATABASEDataSet3BindingSource
        '
        'SubjectsTableAdapter
        '
        Me.SubjectsTableAdapter.ClearBeforeFill = True
        '
        'StudentsTableAdapter
        '
        Me.StudentsTableAdapter.ClearBeforeFill = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Button3)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.TextBox1)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox1.Location = New System.Drawing.Point(644, 38)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(484, 86)
        Me.GroupBox1.TabIndex = 12
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Filter Student"
        '
        'Button3
        '
        Me.Button3.BackgroundImage = Global.LoginForUsers.My.Resources.Resources.refres1
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Location = New System.Drawing.Point(437, 29)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(36, 37)
        Me.Button3.TabIndex = 3
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Transparent
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(326, 29)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(87, 37)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "By Name"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(13, 34)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(280, 26)
        Me.TextBox1.TabIndex = 0
        '
        'StudentsTableAdapter1
        '
        Me.StudentsTableAdapter1.ClearBeforeFill = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(25, 146)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(67, 20)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "Credit :"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.ComboBox2)
        Me.GroupBox2.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox2.Location = New System.Drawing.Point(28, 194)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(257, 183)
        Me.GroupBox2.TabIndex = 21
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Subject 1:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SubjectsBindingSource1, "SubjectName", True))
        Me.Label13.DataBindings.Add(New System.Windows.Forms.Binding("Tag", Me.SubjectsBindingSource1, "SubjectName", True))
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(25, 117)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(24, 20)
        Me.Label13.TabIndex = 17
        Me.Label13.Text = "---"
        '
        'SubjectsBindingSource1
        '
        Me.SubjectsBindingSource1.DataMember = "Subjects"
        Me.SubjectsBindingSource1.DataSource = Me.LiraDatabaseLatestBindingSource
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(25, 87)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(126, 20)
        Me.Label12.TabIndex = 16
        Me.Label12.Text = "Subject Name:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.DataBindings.Add(New System.Windows.Forms.Binding("Tag", Me.SubjectsBindingSource1, "Credit", True))
        Me.Label11.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SubjectsBindingSource1, "Credit", True))
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(90, 146)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(24, 20)
        Me.Label11.TabIndex = 15
        Me.Label11.Text = "---"
        '
        'ComboBox2
        '
        Me.ComboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.ComboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBox2.DataSource = Me.SubjectsBindingSource1
        Me.ComboBox2.DisplayMember = "Code"
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(29, 36)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(211, 27)
        Me.ComboBox2.TabIndex = 0
        Me.ComboBox2.ValueMember = "SubjectName"
        '
        'StudentsBindingSource3
        '
        Me.StudentsBindingSource3.DataMember = "Students"
        Me.StudentsBindingSource3.DataSource = Me.LiraDatabaseLatestBindingSource
        '
        'SubjectsTableAdapter1
        '
        Me.SubjectsTableAdapter1.ClearBeforeFill = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.ComboBox5)
        Me.GroupBox3.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox3.Location = New System.Drawing.Point(310, 194)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(257, 183)
        Me.GroupBox3.TabIndex = 22
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Subject 2:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.DataBindings.Add(New System.Windows.Forms.Binding("Tag", Me.SubjectsBindingSource, "SubjectName", True))
        Me.Label15.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SubjectsBindingSource, "SubjectName", True))
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(25, 117)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(24, 20)
        Me.Label15.TabIndex = 19
        Me.Label15.Text = "---"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.DataBindings.Add(New System.Windows.Forms.Binding("Tag", Me.SubjectsBindingSource, "Credit", True))
        Me.Label14.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SubjectsBindingSource, "Credit", True))
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(90, 146)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(24, 20)
        Me.Label14.TabIndex = 18
        Me.Label14.Text = "---"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(25, 87)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(126, 20)
        Me.Label16.TabIndex = 18
        Me.Label16.Text = "Subject Name:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(25, 146)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(67, 20)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Credit :"
        '
        'ComboBox5
        '
        Me.ComboBox5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.ComboBox5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBox5.DataSource = Me.SubjectsBindingSource
        Me.ComboBox5.DisplayMember = "Code"
        Me.ComboBox5.FormattingEnabled = True
        Me.ComboBox5.Location = New System.Drawing.Point(29, 36)
        Me.ComboBox5.Name = "ComboBox5"
        Me.ComboBox5.Size = New System.Drawing.Size(211, 27)
        Me.ComboBox5.TabIndex = 0
        Me.ComboBox5.ValueMember = "SubjectName"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label17)
        Me.GroupBox4.Controls.Add(Me.Label4)
        Me.GroupBox4.Controls.Add(Me.Label18)
        Me.GroupBox4.Controls.Add(Me.ComboBox7)
        Me.GroupBox4.Controls.Add(Me.Label19)
        Me.GroupBox4.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox4.Location = New System.Drawing.Point(591, 194)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(257, 183)
        Me.GroupBox4.TabIndex = 23
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Subject 3:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.DataBindings.Add(New System.Windows.Forms.Binding("Tag", Me.SubjectsBindingSource2, "SubjectName", True))
        Me.Label17.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SubjectsBindingSource2, "SubjectName", True))
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(25, 117)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(24, 20)
        Me.Label17.TabIndex = 22
        Me.Label17.Text = "---"
        '
        'SubjectsBindingSource2
        '
        Me.SubjectsBindingSource2.DataMember = "Subjects"
        Me.SubjectsBindingSource2.DataSource = Me.LiraDatabaseLatestBindingSource
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(25, 146)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(67, 20)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "Credit :"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.DataBindings.Add(New System.Windows.Forms.Binding("Tag", Me.SubjectsBindingSource2, "Credit", True))
        Me.Label18.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SubjectsBindingSource2, "Credit", True))
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(90, 146)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(24, 20)
        Me.Label18.TabIndex = 20
        Me.Label18.Text = "---"
        '
        'ComboBox7
        '
        Me.ComboBox7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.ComboBox7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBox7.DataSource = Me.SubjectsBindingSource2
        Me.ComboBox7.DisplayMember = "Code"
        Me.ComboBox7.FormattingEnabled = True
        Me.ComboBox7.Location = New System.Drawing.Point(29, 36)
        Me.ComboBox7.Name = "ComboBox7"
        Me.ComboBox7.Size = New System.Drawing.Size(211, 27)
        Me.ComboBox7.TabIndex = 0
        Me.ComboBox7.ValueMember = "Code"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(25, 87)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(126, 20)
        Me.Label19.TabIndex = 21
        Me.Label19.Text = "Subject Name:"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Label20)
        Me.GroupBox5.Controls.Add(Me.Label5)
        Me.GroupBox5.Controls.Add(Me.Label21)
        Me.GroupBox5.Controls.Add(Me.ComboBox9)
        Me.GroupBox5.Controls.Add(Me.Label22)
        Me.GroupBox5.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox5.Location = New System.Drawing.Point(871, 194)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(257, 183)
        Me.GroupBox5.TabIndex = 23
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Subject 4:"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.DataBindings.Add(New System.Windows.Forms.Binding("Tag", Me.SubjectsBindingSource3, "SubjectName", True))
        Me.Label20.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SubjectsBindingSource3, "SubjectName", True))
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(25, 117)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(24, 20)
        Me.Label20.TabIndex = 25
        Me.Label20.Text = "---"
        '
        'SubjectsBindingSource3
        '
        Me.SubjectsBindingSource3.DataMember = "Subjects"
        Me.SubjectsBindingSource3.DataSource = Me.LiraDatabaseLatestBindingSource
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(25, 146)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(67, 20)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Credit :"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.DataBindings.Add(New System.Windows.Forms.Binding("Tag", Me.SubjectsBindingSource3, "Credit", True))
        Me.Label21.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SubjectsBindingSource3, "Credit", True))
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(90, 146)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(24, 20)
        Me.Label21.TabIndex = 23
        Me.Label21.Text = "---"
        '
        'ComboBox9
        '
        Me.ComboBox9.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.ComboBox9.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBox9.DataSource = Me.SubjectsBindingSource3
        Me.ComboBox9.DisplayMember = "Code"
        Me.ComboBox9.FormattingEnabled = True
        Me.ComboBox9.Location = New System.Drawing.Point(29, 36)
        Me.ComboBox9.Name = "ComboBox9"
        Me.ComboBox9.Size = New System.Drawing.Size(211, 27)
        Me.ComboBox9.TabIndex = 0
        Me.ComboBox9.ValueMember = "Code"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(25, 87)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(126, 20)
        Me.Label22.TabIndex = 24
        Me.Label22.Text = "Subject Name:"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.SystemColors.Control
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button2.Location = New System.Drawing.Point(1007, 136)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(121, 41)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "Insert Data"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.Label23)
        Me.GroupBox6.Controls.Add(Me.Label6)
        Me.GroupBox6.Controls.Add(Me.Label24)
        Me.GroupBox6.Controls.Add(Me.ComboBox11)
        Me.GroupBox6.Controls.Add(Me.Label25)
        Me.GroupBox6.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox6.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox6.Location = New System.Drawing.Point(28, 398)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(257, 183)
        Me.GroupBox6.TabIndex = 24
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Subject 5:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.DataBindings.Add(New System.Windows.Forms.Binding("Tag", Me.SubjectsBindingSource4, "SubjectName", True))
        Me.Label23.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SubjectsBindingSource4, "SubjectName", True))
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(25, 117)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(24, 20)
        Me.Label23.TabIndex = 28
        Me.Label23.Text = "---"
        '
        'SubjectsBindingSource4
        '
        Me.SubjectsBindingSource4.DataMember = "Subjects"
        Me.SubjectsBindingSource4.DataSource = Me.LiraDatabaseLatestBindingSource
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(25, 150)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(67, 20)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Credit :"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.DataBindings.Add(New System.Windows.Forms.Binding("Tag", Me.SubjectsBindingSource4, "Credit", True))
        Me.Label24.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SubjectsBindingSource4, "Credit", True))
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(90, 152)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(24, 20)
        Me.Label24.TabIndex = 26
        Me.Label24.Text = "---"
        '
        'ComboBox11
        '
        Me.ComboBox11.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.ComboBox11.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBox11.DataSource = Me.SubjectsBindingSource4
        Me.ComboBox11.DisplayMember = "Code"
        Me.ComboBox11.FormattingEnabled = True
        Me.ComboBox11.Location = New System.Drawing.Point(29, 36)
        Me.ComboBox11.Name = "ComboBox11"
        Me.ComboBox11.Size = New System.Drawing.Size(211, 27)
        Me.ComboBox11.TabIndex = 0
        Me.ComboBox11.ValueMember = "Code"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(25, 87)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(126, 20)
        Me.Label25.TabIndex = 27
        Me.Label25.Text = "Subject Name:"
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.Label26)
        Me.GroupBox7.Controls.Add(Me.Label7)
        Me.GroupBox7.Controls.Add(Me.Label27)
        Me.GroupBox7.Controls.Add(Me.ComboBox13)
        Me.GroupBox7.Controls.Add(Me.Label28)
        Me.GroupBox7.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox7.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox7.Location = New System.Drawing.Point(310, 398)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(257, 183)
        Me.GroupBox7.TabIndex = 24
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Subject 6:"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.DataBindings.Add(New System.Windows.Forms.Binding("Tag", Me.SubjectsBindingSource5, "SubjectName", True))
        Me.Label26.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SubjectsBindingSource5, "SubjectName", True))
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(25, 117)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(24, 20)
        Me.Label26.TabIndex = 31
        Me.Label26.Text = "---"
        '
        'SubjectsBindingSource5
        '
        Me.SubjectsBindingSource5.DataMember = "Subjects"
        Me.SubjectsBindingSource5.DataSource = Me.LiraDatabaseLatestBindingSource
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(25, 150)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(67, 20)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Credit :"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.DataBindings.Add(New System.Windows.Forms.Binding("Tag", Me.SubjectsBindingSource5, "Credit", True))
        Me.Label27.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SubjectsBindingSource5, "Credit", True))
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(90, 152)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(24, 20)
        Me.Label27.TabIndex = 29
        Me.Label27.Text = "---"
        '
        'ComboBox13
        '
        Me.ComboBox13.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.ComboBox13.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBox13.DataSource = Me.SubjectsBindingSource5
        Me.ComboBox13.DisplayMember = "Code"
        Me.ComboBox13.FormattingEnabled = True
        Me.ComboBox13.Location = New System.Drawing.Point(29, 36)
        Me.ComboBox13.Name = "ComboBox13"
        Me.ComboBox13.Size = New System.Drawing.Size(211, 27)
        Me.ComboBox13.TabIndex = 0
        Me.ComboBox13.ValueMember = "Code"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(25, 87)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(126, 20)
        Me.Label28.TabIndex = 30
        Me.Label28.Text = "Subject Name:"
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.Label29)
        Me.GroupBox8.Controls.Add(Me.Label8)
        Me.GroupBox8.Controls.Add(Me.Label30)
        Me.GroupBox8.Controls.Add(Me.ComboBox15)
        Me.GroupBox8.Controls.Add(Me.Label31)
        Me.GroupBox8.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox8.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox8.Location = New System.Drawing.Point(591, 398)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(257, 183)
        Me.GroupBox8.TabIndex = 24
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Subject 7:"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.DataBindings.Add(New System.Windows.Forms.Binding("Tag", Me.SubjectsBindingSource6, "SubjectName", True))
        Me.Label29.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SubjectsBindingSource6, "SubjectName", True))
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(25, 117)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(24, 20)
        Me.Label29.TabIndex = 34
        Me.Label29.Text = "---"
        '
        'SubjectsBindingSource6
        '
        Me.SubjectsBindingSource6.DataMember = "Subjects"
        Me.SubjectsBindingSource6.DataSource = Me.LiraDatabaseLatestBindingSource
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(25, 148)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(67, 20)
        Me.Label8.TabIndex = 13
        Me.Label8.Text = "Credit :"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.DataBindings.Add(New System.Windows.Forms.Binding("Tag", Me.SubjectsBindingSource6, "Credit", True))
        Me.Label30.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SubjectsBindingSource6, "Credit", True))
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(90, 150)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(24, 20)
        Me.Label30.TabIndex = 32
        Me.Label30.Text = "---"
        '
        'ComboBox15
        '
        Me.ComboBox15.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.ComboBox15.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBox15.DataSource = Me.SubjectsBindingSource6
        Me.ComboBox15.DisplayMember = "Code"
        Me.ComboBox15.FormattingEnabled = True
        Me.ComboBox15.Location = New System.Drawing.Point(29, 36)
        Me.ComboBox15.Name = "ComboBox15"
        Me.ComboBox15.Size = New System.Drawing.Size(211, 27)
        Me.ComboBox15.TabIndex = 0
        Me.ComboBox15.ValueMember = "Code"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(25, 87)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(126, 20)
        Me.Label31.TabIndex = 33
        Me.Label31.Text = "Subject Name:"
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.Label32)
        Me.GroupBox9.Controls.Add(Me.Label9)
        Me.GroupBox9.Controls.Add(Me.Label33)
        Me.GroupBox9.Controls.Add(Me.ComboBox17)
        Me.GroupBox9.Controls.Add(Me.Label34)
        Me.GroupBox9.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox9.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox9.Location = New System.Drawing.Point(871, 398)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(257, 183)
        Me.GroupBox9.TabIndex = 24
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Subject 8:"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.DataBindings.Add(New System.Windows.Forms.Binding("Tag", Me.SubjectsBindingSource7, "SubjectName", True))
        Me.Label32.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SubjectsBindingSource7, "SubjectName", True))
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(25, 117)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(24, 20)
        Me.Label32.TabIndex = 37
        Me.Label32.Text = "---"
        '
        'SubjectsBindingSource7
        '
        Me.SubjectsBindingSource7.DataMember = "Subjects"
        Me.SubjectsBindingSource7.DataSource = Me.LiraDatabaseLatestBindingSource
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(25, 148)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(67, 20)
        Me.Label9.TabIndex = 13
        Me.Label9.Text = "Credit :"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.DataBindings.Add(New System.Windows.Forms.Binding("Tag", Me.SubjectsBindingSource7, "Credit", True))
        Me.Label33.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SubjectsBindingSource7, "Credit", True))
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(90, 150)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(24, 20)
        Me.Label33.TabIndex = 35
        Me.Label33.Text = "---"
        '
        'ComboBox17
        '
        Me.ComboBox17.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.ComboBox17.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBox17.DataSource = Me.SubjectsBindingSource7
        Me.ComboBox17.DisplayMember = "Code"
        Me.ComboBox17.FormattingEnabled = True
        Me.ComboBox17.Location = New System.Drawing.Point(29, 36)
        Me.ComboBox17.Name = "ComboBox17"
        Me.ComboBox17.Size = New System.Drawing.Size(211, 27)
        Me.ComboBox17.TabIndex = 0
        Me.ComboBox17.ValueMember = "Code"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(25, 87)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(126, 20)
        Me.Label34.TabIndex = 36
        Me.Label34.Text = "Subject Name:"
        '
        'StudentsBindingSource4
        '
        Me.StudentsBindingSource4.DataMember = "Students"
        Me.StudentsBindingSource4.DataSource = Me.LiraDatabaseLatestBindingSource
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.DataBindings.Add(New System.Windows.Forms.Binding("Tag", Me.StudentsBindingSource2, "StudentIC", True))
        Me.Label35.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentsBindingSource2, "StudentIC", True))
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(180, 87)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(24, 20)
        Me.Label35.TabIndex = 19
        Me.Label35.Text = "---"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(37, 87)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(104, 20)
        Me.Label36.TabIndex = 18
        Me.Label36.Text = "IC Number :"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(37, 117)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(114, 20)
        Me.Label38.TabIndex = 26
        Me.Label38.Text = "Class Name :"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.DataBindings.Add(New System.Windows.Forms.Binding("Tag", Me.StudentsBindingSource2, "StudentEmail", True))
        Me.Label39.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentsBindingSource2, "StudentEmail", True))
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(182, 149)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(24, 20)
        Me.Label39.TabIndex = 29
        Me.Label39.Text = "---"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(38, 149)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(134, 20)
        Me.Label40.TabIndex = 28
        Me.Label40.Text = "Email Address :"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label37.DataBindings.Add(New System.Windows.Forms.Binding("Tag", Me.StudentsBindingSource2, "StudentClass", True))
        Me.Label37.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentsBindingSource2, "StudentClass", True))
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(181, 117)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(24, 20)
        Me.Label37.TabIndex = 27
        Me.Label37.Text = "---"
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.SystemColors.Control
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button4.Location = New System.Drawing.Point(900, 136)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(76, 41)
        Me.Button4.TabIndex = 30
        Me.Button4.Text = "Clear"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(37, 59)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(129, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Student Name:"
        '
        'ComboBox1
        '
        Me.ComboBox1.DataSource = Me.StudentsBindingSource2
        Me.ComboBox1.DisplayMember = "StudentName"
        Me.ComboBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(180, 56)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(281, 28)
        Me.ComboBox1.TabIndex = 1
        Me.ComboBox1.ValueMember = "StudentName"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Black
        Me.MenuStrip1.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RegisteredStudentsListToolStripMenuItem, Me.StudentsRegisteredSubjectsToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1160, 29)
        Me.MenuStrip1.TabIndex = 31
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'RegisteredStudentsListToolStripMenuItem
        '
        Me.RegisteredStudentsListToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.RegisteredStudentsListToolStripMenuItem.Name = "RegisteredStudentsListToolStripMenuItem"
        Me.RegisteredStudentsListToolStripMenuItem.Size = New System.Drawing.Size(194, 25)
        Me.RegisteredStudentsListToolStripMenuItem.Text = "Registered Students List"
        '
        'StudentsRegisteredSubjectsToolStripMenuItem
        '
        Me.StudentsRegisteredSubjectsToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.StudentsRegisteredSubjectsToolStripMenuItem.Name = "StudentsRegisteredSubjectsToolStripMenuItem"
        Me.StudentsRegisteredSubjectsToolStripMenuItem.Size = New System.Drawing.Size(230, 25)
        Me.StudentsRegisteredSubjectsToolStripMenuItem.Text = "Student's Registered Subjects"
        '
        'FormRegister
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Highlight
        Me.ClientSize = New System.Drawing.Size(1160, 609)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Label39)
        Me.Controls.Add(Me.Label40)
        Me.Controls.Add(Me.Label37)
        Me.Controls.Add(Me.Label38)
        Me.Controls.Add(Me.Label35)
        Me.Controls.Add(Me.Label36)
        Me.Controls.Add(Me.GroupBox9)
        Me.Controls.Add(Me.GroupBox8)
        Me.Controls.Add(Me.GroupBox7)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.ForeColor = System.Drawing.Color.White
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "FormRegister"
        Me.Text = "FormRegister"
        CType(Me.StudentsBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LiraDatabaseLatestBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LiraDatabaseLatest, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StudentsBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StudentsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LIRADATABASEDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LIRADATABASEDataSet3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LIRADATABASEDataSet3BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SubjectsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.SubjectsBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StudentsBindingSource3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.SubjectsBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        CType(Me.SubjectsBindingSource3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        CType(Me.SubjectsBindingSource4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        CType(Me.SubjectsBindingSource5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        CType(Me.SubjectsBindingSource6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        CType(Me.SubjectsBindingSource7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StudentsBindingSource4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LIRADATABASEDataSet3BindingSource As BindingSource
    Friend WithEvents LIRADATABASEDataSet3 As LIRADATABASEDataSet3
    Friend WithEvents SubjectsBindingSource As BindingSource
    Friend WithEvents SubjectsTableAdapter As LIRADATABASEDataSet3TableAdapters.SubjectsTableAdapter
    Friend WithEvents LIRADATABASEDataSet As LIRADATABASEDataSet
    Friend WithEvents StudentsBindingSource As BindingSource
    Friend WithEvents StudentsTableAdapter As LIRADATABASEDataSetTableAdapters.StudentsTableAdapter
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Button3 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents LiraDatabaseLatest As LiraDatabaseLatest
    Friend WithEvents StudentsBindingSource1 As BindingSource
    Friend WithEvents StudentsTableAdapter1 As LiraDatabaseLatestTableAdapters.StudentsTableAdapter
    Friend WithEvents StudentsBindingSource2 As BindingSource
    Friend WithEvents LiraDatabaseLatestBindingSource As BindingSource
    Friend WithEvents Label2 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents StudentsBindingSource3 As BindingSource
    Friend WithEvents SubjectsBindingSource1 As BindingSource
    Friend WithEvents SubjectsTableAdapter1 As LiraDatabaseLatestTableAdapters.SubjectsTableAdapter
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Label3 As Label
    Friend WithEvents ComboBox5 As ComboBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents Label4 As Label
    Friend WithEvents ComboBox7 As ComboBox
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents Label5 As Label
    Friend WithEvents ComboBox9 As ComboBox
    Friend WithEvents Button2 As Button
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents Label6 As Label
    Friend WithEvents ComboBox11 As ComboBox
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents Label7 As Label
    Friend WithEvents ComboBox13 As ComboBox
    Friend WithEvents GroupBox8 As GroupBox
    Friend WithEvents Label8 As Label
    Friend WithEvents ComboBox15 As ComboBox
    Friend WithEvents GroupBox9 As GroupBox
    Friend WithEvents Label9 As Label
    Friend WithEvents ComboBox17 As ComboBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents SubjectsBindingSource2 As BindingSource
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents SubjectsBindingSource3 As BindingSource
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents StudentsBindingSource4 As BindingSource
    Friend WithEvents Label23 As Label
    Friend WithEvents SubjectsBindingSource4 As BindingSource
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents SubjectsBindingSource5 As BindingSource
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents SubjectsBindingSource6 As BindingSource
    Friend WithEvents SubjectsBindingSource7 As BindingSource
    Friend WithEvents Label35 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Button4 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents RegisteredStudentsListToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents StudentsRegisteredSubjectsToolStripMenuItem As ToolStripMenuItem
End Class
